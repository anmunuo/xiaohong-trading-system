# 系统审查陷阱清单

2026-05-27 全面复盘发现的 14 项问题，按严重程度分级。维护者应在每次修改后检查这些陷阱是否仍存在。

---

## 🔴 P0 — 安全/数据正确性

### 1. Tushare Token 硬编码
- **位置**：`data_pipeline.py:43`
- **问题**：`TUSHARE_TOKEN = "71fc82ff..."` 明文写在代码中
- **修复**：改为 `os.environ.get('TUSHARE_TOKEN')`，token 只存在于 `.env`

### 2. 账户净值未同步市值
- **位置**：`holdings.json` → `accountInfo.currentNetValue`
- **问题**：净值 ¥832,045 停滞在 4 月，实际净值 ¥898,698（偏差 +¥66,653 / +8%）
- **影响**：R 值、仓位百分比全部基于过期净值
- **修复**：`ammo_risk.py --update` 时同步 `currentNetValue = availableCash + sum(marketValue)`

### 3. 移动止损从未更新
- **位置**：`holdings.json` → 所有批次 `trailingStopUpdated = 2026-04-01`
- **问题**：英唐智控浮盈 +42.4%，按规则应上移止损 ≥2 次，但止损线停在 4 月
- **规则**：涨 20% → 上移到成本（保本）→ 每涨 10% 再上移 10%
- **修复**：弹药库增加移动止盈自动计算

---

## 🟡 P1 — 数据/调度

### 4. Cron 时间冲突
- 08:30：`小红·盘前采集` vs `🔭 瞭望塔`
- 15:30：`小红·盘后复盘` vs `🛡️ 弹药库`

### 5. Cron 冗余（3 份周复盘）
- `8ca5688b71fa` 周六 10:00 script
- `a904cd4aa19b` 周六 10:30 LLM
- `1de9a545a043` 周六 09:00 script
- 建议：保留新版 `1de9a545a043`，停用另外两个

### 6. 狙击手使用旧 API
- **位置**：`sniper.py:23,48`
- **问题**：用 `get_individual_money_flow()` 而不是 `get_stock_realtime()`，盘后价格返回 0 → 表格显示 "N/A"
- **修复**：改用 `get_stock_realtime(codes)` 获取日线收盘价

### 7. 复盘脚本用假数据
- **位置**：`review.py:75-76`
- **问题**：引用 `h.get('profitRate')` 字段——该字段在 holdings.json 中不存在，永远显示 `+0.0%`
- **修复**：引入 `get_stock_realtime()` 计算实盘盈亏

### 8. 数据管线 15 处静默异常
- **位置**：`data_pipeline.py`
- **问题**：`except: pass` 出现 15 次，任何数据源故障完全不可见
- **修复**：至少加 `print(f"⚠️ {func_name}: {e}", file=sys.stderr)`

---

## 🟢 P2 — 功能完整性

### 9. validate_all_strategies 只验证选股类
- **位置**：`strategies/__init__.py`
- **问题**：if/else 只处理 `category == "selection"`，position/stop/composite 全部误报 "⚠️ 未实现"

### 10. weekly_review.py 空壳
- **位置**：`weekly_review.py:38`
- **问题**：`# TODO: 实现周度复盘逻辑` — 无实质内容

### 11. 侦察兵盘后永远 0 候选
- **问题**：非交易时段 `get_top_flow_stocks(30)` 返回空，无回退方案
- **建议**：盘后用前一日数据或降级为 "等待开盘"

### 12. feishu_push.py 静默失败
- **问题**：依赖 `.env.feishu` 文件，不存在时 `--push` 静默无输出

### 13. 策略参数文件缺失
- **问题**：`strategies/params/*.json` 不存在，策略只用代码默认参数

### 14. holdings.json updateTime 不可信
- **问题**：`updateTime` 不会自动维护，上次手动更新日期不明

### 15. data fetch 不能用于上证指数
- **陷阱**：`data fetch stock --symbol 000001 --category quote` 返回的是**平安银行(000001.SZ)**，不是上证指数
- **正确**：`ak.stock_zh_index_daily(symbol='sh000001')` 获取上证日线
- **教训**：data fetch CLI 只支持个股代码，指数数据必须走 akshare

### 16. 板块关键词误伤（P1）
- **位置**：`resource_pool.py` → `SECTOR_KEYWORD_MAP`
- **案例**：`'存储'` 匹配到丸美生物的「募集资金专户**存储**」→ 化妆品公司被归入半导体；`'数字'` 匹配到「**数字**证书」
- **修复**：① 替换单字词为复合词（`'存储'`→`'存储芯片'`）；② 添加 `SECTOR_NEGATIVE_FILTERS` 负向排除（如「募集资金」「资金存储」排除半导体）
- **原则**：单字/二字通用词必须复合化或加负向排除，宁可漏归不可误归

### 17. 事件双重计数（P1）
- **位置**：`watchtower.py` → `_pick_stocks_multi_dim()`
- **症状**：佰维存储实际 2 条公告，报告显示 4 条（翻倍）；西昌电力 1→2 条
- **根因**：先从 `key_stocks.event_count` 累加一次，再从 `announcements` 遍历累加第二次
- **修复**：事件统计改为单源——只从 `announcements` 遍历统计，`key_stocks` 只补充 lianban 不补 event_count

### 18. 无标签公告丢失（P2）
- **位置**：`resource_pool.py` → `cross_validate_sectors()`
- **症状**：佰维存储公告标题不含板块关键词，sector_tags=[]，被排除在板块聚合之外
- **修复**：对无 sector_tag 但有 code 的公告，从涨停池 `所属行业` 字段推断行业归属
- **局限**：仅覆盖涨停池内的股票，非涨停股仍需公司名关键词匹配

### 19. 北向资金数据不一致——晨报 vs 瞭望塔（P0）⚠️


---
## 🟢 P2 — 功能完整性（续）

### 20. SQLite INSERT 列数不匹配（P2）🔧
- **位置**：`transaction_logger.py:160`
- **症状**：`OperationalError: table transactions has 26 columns but 25 values were supplied`
- **根因**：INSERT 语句中 `?` 占位符数量与参数元组长度不一致——表有 26 列（含 id autoincrement），INSERT 用 `NULL + 23×? + datetime` = 25 values，但参数元组有 24 个值，需 24×`?`
- **修复**：数清楚占位符——`NULL + 24×? + datetime('now')` = 26 values，匹配 26 columns
- **教训**：写 SQL INSERT 时**逐列计数**，不要凭感觉写 `?` 数量；调试时用 `PRAGMA table_info(transactions)` 查看实际列数和顺序

### 21. MACD dea 数组对齐错误（P2）🔧
- **位置**：`strategies/trading_skill_strategies.py:84-95`
- **症状**：`ValueError: could not broadcast input array from shape (95,) into shape (87,)`
- **根因**：对 `dif` 的非 NaN 部分计算 `dea = ema(valid_dif, signal)` 后，`dea` 的长度是 `len(valid_dif)`，但对齐索引 `start_idx = np.argmax(~np.isnan(dif)) + signal - 1` 计算错误——EMA 本身会再产生 signal-1 个 NaN，导致 `dea` 实际有效长度 < `len(valid_dif)`
- **修复**：先对去 NaN 的 dif 算 dea，再对 dea 去 NaN，**分别计算切片的 start 和 end 索引**，确保 `dea_full[start:end] = dea_on_valid[:end-start]` 两边长度一致
- **教训**：多层 EMA（EMA on EMA）会导致 NaN 传播，每次对接时必须重新去 NaN 并分别计算对齐索引，**min(end_idx, array_length)** 防御溢出
- **位置**：`market_data_collector.sh:63,106` + 晨报 cron prompt
- **症状**：晨报显示 249 亿，瞭望塔显示 5.4 亿——46 倍偏差
- **根因三重**：
  1. `data fetch stock "" --type northbound` 返回 `"please specify --symbol"` → 采集管线永久失败
  2. 晨报 LLM 发现 wiki 为空后，回退到 web search → 搜到错误数字（249亿）
  3. 晨报 prompt 没有指定 `data_pipeline.get_north_flow()` 作为唯一数据源
- **修复**：
  1. `market_data_collector.sh` → 北向采集改为 `fetch_northbound.py` → `data_pipeline.get_north_flow()`
  2. 晨报 cron prompt → 加入 pipeline 调用指令 + 禁止 web search 替代 + 交叉验证规则
  3. 新增 `scripts/fetch_northbound.py` 作为北向数据采集器
- **原则**：市场级数据（北向/龙虎榜/板块）不能依赖 `data fetch` CLI，必须走 `data_pipeline`

---

## 检查脚本

```bash
# 快速健康检查
cd ~/.hermes/profiles/xiaohong

# Token 泄露
grep -rn "71fc82ff" scripts/data_pipeline.py && echo "🔴 TOKEN 硬编码!" || echo "✅"

# 异常吞没
grep -c "except: pass" scripts/data_pipeline.py

# 净值偏差
python3 -c "
import json
d=json.load(open('data/holdings.json'))
old=d['accountInfo']['currentNetValue']
cash=d['accountInfo']['availableCash']
mv=sum(h.get('marketValue',h['totalCost']) for h in d['holdings'])
actual=cash+mv
print(f'净值偏差: ¥{actual-old:+,.0f} ({(actual-old)/old*100:+.1f}%)')
"

# 止损过期
python3 -c "
import json
d=json.load(open('data/holdings.json'))
for h in d['holdings']:
    for t in h.get('trades',[]):
        if t.get('trailingStopUpdated','') < '2026-05':
            print(f\"🔴 {h['name']} {t['batchId']}: trailingStopUpdated={t['trailingStopUpdated']} 过期!\")
"