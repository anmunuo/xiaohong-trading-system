# Report Formatter API

位于 `~/.hermes/profiles/xiaohong/scripts/report_formatter.py`。

## Report 类

```python
from report_formatter import Report

r = Report(title="标题", icon="🔭", color="blue")
```

| 参数 | 类型 | 说明 |
|------|------|------|
| `title` | str | 报告标题 |
| `icon` | str | 标题前缀 emoji |
| `color` | str | 主题色：`blue/green/red/yellow/purple` |

## 链式方法

| 方法 | 参数 | 说明 |
|------|------|------|
| `.header_meta(**kwargs)` | 键值对 | 标题下方元信息行 |
| `.section(title)` | str | 章节标题（粗体 ▸ 前缀） |
| `.text(content)` | str | 文本段落 |
| `.kv(key, value, sub="")` | str×3 | 键值对行，sub 为灰色副文本 |
| `.table(headers, rows)` | list×2 | Markdown 表格 |
| `.divider()` | — | 分割线 `---` |
| `.alert(msg, level)` | str×2 | 颜色告警（critical🔴/warning🟡/info🔵） |
| `.footer(text)` | str | 斜体页脚 |
| `.markdown()` | — | 输出增强 Markdown（cron no_agent stdout） |
| `.card()` | — | 输出飞书交互卡片 JSON（带标题栏配色） |

## 使用模式

**cron no_agent 脚本** → 调用 `.markdown()` 输出，stdout 自动投递：
```python
r = Report(...)
r.section("持仓")  # 链式构建
print(r.markdown())
```

**--push 模式** → 可输出 `.card()` JSON 用于飞书交互卡片。

## 飞书卡片效果

- `.card()` 生成带 `header.template` 配色的交互卡片
- 支持 `wide_screen_mode`
- `div` 块用 `lark_md` 渲染 Markdown
- `note` 元素做灰色页脚
- 颜色告警用 `<font color='red'>` 标签
