---
name: stock-research
description: 小红股票投研工作流 —— 数据获取、筛选、分析的全链路规范
triggers:
  - "分析.*股票"
  - "自选池"
  - "筛选.*股票"
  - "选股"
  - "股票.*研究"
  - "基本面.*分析"
  - "技术面.*分析"
  - "买卖点"
  - "催化剂"
  - "交易系统|策略分析"
  - "资源池|事件驱动"
  - "瞭望塔|晨报|瞭望塔晨报|盘前报告"
  - "交叉验证|多维选股"
  - "自查.*数据|假数据|虚构|数据真实"
  - "知识库|知识库检索|每小时采集|最新线索"
  - "Skills.*MCP|claude-trading-skills|Skills架构"
  - "交易系统.*架构|系统全景|整体架构"
  - "部署|Docker.*交易|硬件盒子|Pi.*交易"
  - "TradingSkill|交易系统升级|产品化|硬件盒子|小程序|MCP"
  - "对标.*系统|交易日志|结构化日志|Paper Trading"
---

# 小红 · 股票投研工作流

## ⛔ 铁律

**禁止凭空捏造数据或标的。** 所有代码、估值、财务数据必须来自真实数据源。不得拍脑袋预设自选池、不得编造 PE/PB/ROE 数值、不得在没有数据的情况下断言涨跌逻辑。

当不确定数据是否可用时，先探测，再说话。宁可不给结论，不给假结论。

**大规模改动必须先展示方案**：涉及系统架构变更、多模块重构、新产品化功能时，必须先输出完整技术方案（架构全景 + 优化项 + 执行顺序 + 风险评估），待用户审阅确认后再动手编码。禁止跳过方案阶段直接写代码。

---

## 数据源能力矩阵

### data_pipeline 统一管道（⭐ 推荐首选）

位于 `~/.hermes/profiles/xiaohong/scripts/data_pipeline.py`。

```bash
cd ~/.hermes/profiles/xiaohong/scripts
python3 -c "from data_pipeline import get_index_data; print(get_index_data())"
```

封装了 Tushare/AKShare/东方财富/Sina 四源聚合，内置 2-5 分钟缓存和自动 fallback。覆盖：全球指数、北向资金、板块排名、个股资金流向、选股推荐。

**核心 API 速查**：

| 函数 | 用途 | 参数 |
|------|------|------|
| `get_index_data()` | 全球指数（美/欧/亚） | 无 |
| `get_north_flow()` | 北向资金流向 | 无 |
| `get_sector_flow_rank(sector_type='3')` | 板块资金排名 | sector_type: 行业分类 |
| `get_top_flow_stocks(n=10)` | 个股净流入 TOP N | n: 返回数量 |
| `get_market_money_flow()` | 全市场主力/散户资金 | 无 |
| `get_stock_candidates()` | 多因子选股推荐 | 无 |
| `get_watchlist()` | 自选股监控 | 无 |

**resource_pool 核心 API**：

| 函数 | 用途 | 返回 |
|------|------|------|
| `build_resource_pool()` | 全量事件采集 | `{announcements, research_reports, policy_news, sector_analysis, summary}` |

> ⚠️ `resource_pool` 导出的是函数 `build_resource_pool()`，非 `ResourcePool` 类。

**v3.1 新增 `get_stock_realtime(codes: list)`**：通过 Hermes `data fetch` CLI 获取个股最新日线（OHLCV），用于止损检查、实时估值。返回 `{code: {close, change_pct, open, high, low, volume, data_source, trade_date}}`。

**安全注意**：Tushare Token 已从硬编码移至 `~/.hermes/profiles/xiaohong/.env`（`TUSHARE_TOKEN=`），`_load_tushare_token()` 自动从 env 或 .env 文件加载。**禁止在代码中硬编码任何 API key。**

**holdings.json 实时估值字段**：运行 `python3 scripts/ammo_risk.py --update` 同步写入 `lastPrice / marketValue / unrealizedPnL / pnlPct / lastUpdate`，同时更新 `currentNetValue` 和触发移动止盈计算。

完整 API 见 → `references/data-source-cheatsheet.md`。

### data fetch CLI（便捷但受限）

| 能力 | 状态 | 用法 |
|------|:--:|------|
| 单票行情 | ✅ | `data fetch stock --symbol 600519 --category quote` |
| 单票日线 | ✅ | `data fetch stock --symbol 600519 --category daily --days 30` |
| 单票财报 | ✅ | `data fetch company --symbol 600519 --category overview` |
| 龙虎榜/北向/涨停 | ❌ | 返回 "please specify --symbol" |
| 全市场筛选 | ❌ | 无此接口 |

**结论：data fetch CLI 只能做单票查询，不能做市场级扫描。**

### 交易日志与执行（v2.0 新增）

| 模块 | 对标 TradingSkill | 入口 |
|------|:--:|------|
| 自动执行器 | `executor.ts` | `python3 scripts/auto_executor.py --once --paper` |
| 交易日志 | `logger.ts` | `python3 scripts/transaction_logger.py stats` |
| Docker 部署 | Dockerfile | `docker-compose up trading-engine -d` |

详见 → `strategy-trading` skill、`references/tradingskill-benchmark.md`

### akshare 直调（补充能力）

通过 `python3 -c "import akshare as ak; ..."` 直接调用。

| 功能 | 函数 | 验证状态 |
|------|------|:--:|
| 涨停板池 | `ak.stock_zt_pool_em(date='YYYYMMDD')` | ✅ |
| 龙虎榜 | `ak.stock_lhb_detail_em(start_date, end_date)` | ✅ |
| 热度排行 | `ak.stock_hot_rank_em()` | ✅ |
| 北向历史 | `ak.stock_hsgt_hist_em(symbol='沪股通')` | ✅ (近期NaN) |
| 沪A实时 | `ak.stock_sh_a_spot_em()` | ⚠️ 限流断连 |
| 深A实时 | `ak.stock_sz_a_spot_em()` | ⚠️ 同上 |
| 公司公告 | `ak.stock_notice_report(symbol='全部', date='YYYYMMDD')` | ✅ 1500+条/日 |
| 券商研报 | `ak.stock_research_report_em(symbol='000001')` | ✅ 评级+盈利预测 |
| 经济日历 | `ak.news_economic_baidu(date='YYYYMMDD')` | ✅ 宏观数据发布 |
| 东方财富新闻 | `ak.stock_news_em()` | ✅ 个股市场新闻 |

### tushare 直调（全市场筛选主力）

通过 `python3 -c "import tushare as ts; pro = ts.pro_api(); ..."` 直接调用。

| 功能 | 函数 | 关键字段 |
|------|------|----------|
| 全A列表 | `pro.stock_basic()` | ts_code, name, industry, list_date |
| 全市场估值 | `pro.daily_basic(trade_date=...)` | pe_ttm, pb, ps_ttm, total_mv, circ_mv |
| 财务指标 | `pro.fina_indicator(ts_code=...)` | roe, roa, netprofit_margin, tr_yoy, debt_to_assets |

---

## 数据单位陷阱

- tushare `total_mv` / `circ_mv` 单位是**万元**，转亿需 **÷ 1e4**（不是 ÷ 1e8）
- tushare `daily_basic` 的 `trade_date` 格式是 `YYYYMMDD` 字符串
- akshare 日期格式视函数而定，有的用 `YYYYMMDD`，有的用 `YYYY-MM-DD`

---

## 筛选工作流

### 标准流程

```
1. pro.stock_basic() → 全A列表 (5522只)
2. pro.daily_basic(trade_date=TODAY) → 估值数据
3. merge → 清洗(去ST/去退市/dropna PE+MV) → 3913有效
4. 应用筛选条件
5. 计算综合评分 → Top N
6. 对Top N逐只拉财务深度数据 → 输出
```

### 筛选条件参考（基于 2026-05-22 真实分布）

PE_TTM 分布 (N=3961):
- 1%: 6.6 | 5%: 12.3 | 10%: 15.5 | 25%: 25.5
- 50%: 49.8 | 75%: 108.9 | 90%: 250.3

PB 分布 (N=3961):
- 1%: 0.55 | 25%: 1.85 | 50%: 2.92 | 75%: 5.00 | 95%: 13.04

### 常见问题

| 症状 | 根因 |
|------|------|
| 筛选结果全是银行 | PE/PB 权重过高 + 未加 ROE/增长因子 |
| 筛选结果 0 只 | 条件过严或单位换算错误 |
| akshare 断连 | 东方财富限流，换 tushare 或稍后重试 |
| tushare Python 直连报 token error | 直接用 `data fetch` CLI 替代，CLI 自带凭证管理 |
| akshare `stock_zh_a_spot_em()` RemoteDisconnected | 东方财富实时行情限流，换 `data fetch stock` 或等 10 分钟重试 |
| akshare 新闻标题为空 | `stock_news_em` 有时截断，改用浏览器直接搜东方财富搜索页 |
| akshare cron 输出污染 | tqdm 进度条输出到 stdout，在脚本开头加 `os.environ['TQDM_DISABLE'] = '1'` |
| akshare `stock_notice_report` 历史数据 | 无参调用返回 2022 数据，必须传 `date='YYYYMMDD'` |
| `data fetch company` 只返回利润表 | `overview`/`balance`/`fina` 三个 category 返回相同数据（仅 income statement），**没有资产负债表和财务比率**。需要 ROE/负债率/毛利率等用 `akshare` 或 `tushare` 直调 |
| akshare `stock_zt_pool_em` 列名不同于文档 | 涨停板列名是 `封板资金`、`连板数`（非 `封单金额`），最新价列是 `最新价`；跌停用 `stock_zt_pool_dtgc_em` |

---

### 数据获取优先级（单票深度分析）

```
Step 1: data fetch stock --symbol XXXX --type daily --days 120  ← 行情+日线
Step 2: data fetch company --symbol XXXX --type overview        ← 历史财报
Step 3: akshare stock_financial_analysis_indicator              ← 财务指标(Roe/负债等)
Step 4: 浏览器搜索 + akshare 龙虎榜/新闻                        ← 资金面+催化剂
Step 5: Python 计算技术指标 (MA/MACD/RSI/布林)                  ← 形态分析
```

估值数据兜底：如果 tushare daily_basic 不可用，用 EPS 和股价反推 PE。

---

## 单票深度分析流程

### 标准四段式

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ 基本面    │ → │ 技术面    │ → │ 催化剂    │ → │ 交易系统  │
│ 估值+财务  │    │ 形态+指标  │    │ 新闻+公告  │    │ 买卖点+仓位│
│ (40%)     │    │ (35%)     │    │ (25%)     │    │ 整合输出  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
```

### 每段产出
1. **基本面**：营收/利润趋势表、ROE/净利率/负债率对比、PE 估值推算、TTM EPS 手工计算
2. **技术面**：多阶段形态划分、均线/MACD/RSI/布林/量价分析、关键支撑阻力位
3. **催化剂**：浏览器搜索公司名+关键词、提取具体进展（送样/定点/量产）、区分确认/传闻/误传
4. **交易系统**：三面共振打分、分批建仓计划、退出机制、情景推演

---

## 技术面分析

### 用 execute_code 批量计算指标

```python
# 从 data fetch 的 JSON 中提取 bars_sorted
closes = [b["close"] for b in bars_sorted]
highs  = [b["high"]  for b in bars_sorted]
lows   = [b["low"]   for b in bars_sorted]
vols   = [b["vol"]   for b in bars_sorted]

# 均线：MA5, MA10, MA20, MA30, MA60（标准 SMA）
# MACD：EMA12, EMA26, DIF, DEA(9), 柱状=2*(DIF-DEA)
# RSI(14)：标准 Wilder 平滑算法
# 布林带(20,2)：中轨=MA20，带宽=2×标准差
# 成交量：5日/20日均量，量比
```

### 形态识别要点
- 阶段划分：底部盘整 → 突破 → 主升 → 冲高回踩（四阶段命名）
- 关键位：前高（阻力 R1）、近期最低（支撑）、MA 支撑位序列
- 量价关系：突破放量(≥2倍地量)、回踩缩量(≤突破量85%) = 筹码锁定
- 回踩质量：回撤幅度（38.2%/50%/61.8% 黄金分割）、是否破前高

### 危险信号
- 放量滞涨（冲高回落+巨量）= 分歧加大
- 连续缩量阴跌（跌破 MA10）= 回踩失败
- RSI > 80 超买 + MACD 顶背离

---

## 催化剂研究

### 浏览器搜索模式

```
URL: https://so.eastmoney.com/news/s?keyword=公司名+关键词&page=1
```

| 搜索目标 | 关键词组合 |
|------|------|
| 客户订单 | 公司名 + 北美/客户/订单/定点 |
| 产品进展 | 公司名 + 送样/验证/量产 |
| 新业务布局 | 公司名 + 机器人/卫星/光模块/AI |
| 互动问答 | 使用"问董秘"标签页 |
| 研报观点 | 使用"研报"标签页 |

### 催化剂分级
- ✅ **已确认**：公司官方互动平台/公告/正规媒体报道中直接引用
- 🔄 **进行中**：有明确时间线但未完成（如送样未定点）
- ⚠️ **传闻/推测**：仅有市场猜测，无官方确认
- ❌ **未发现/误传**：搜索无结果或张冠李戴

---

## 小红交易决策系统

见 `references/trading-system.md`，核心框架：
- **三面共振打分**：基本面(40%)+技术面(35%)+催化剂(25%) → 综合分 /10
- **分批建仓**：底仓(回踩支撑)、加仓(确认反包)、追击(突破确认)、重仓(深度回调)
- **退出机制**：固定止损→移动止盈渐进，关键时间节点（财报）触发审查
- **仓位铁律**：单票≤8%、行业≤15%、分批间隔≥2日、止损无条件执行

## 自动化 Cron 报告系统

11 个 cron 任务（9 个 no_agent + 2 个 LLM 驱动）：

| 时间 | 角色 | 模式 | 投递 |
|------|------|:--:|:--:|
| **每小时** | **📚 知识库·采集** | no_agent | **local** |
| 08:25 | 🎯 选股推荐引擎 v2.0 | no_agent | 飞书 |
| 08:30 | 🌅 瞭望塔晨报 v8.0 | **LLM** | 飞书 |
| 09:25 | 🔍 侦察兵·开盘选股 | no_agent | 飞书 |
| 09:35~14:30 | 🎯 狙击手·日内监控 | no_agent | 飞书 |
| 14:30 | 🌹 决策官·盘中决策 | **LLM** | 飞书 |
| 15:30 | 🛡️ 弹药库·收市风控 | no_agent | 飞书 |
| 17:00 | 🏥 文工团·每日复盘 | no_agent | 飞书 |
| 周六 09:00 | 📊 文工团·周度复盘 | no_agent | 飞书 |

> **v8.0 核心原则**：`daily_pool.json` 是唯一推荐源，晨报 LLM 不做二次选股。推荐引擎排除规则：ST/连板/<50亿/>2000亿，每只股票含选股逻辑+操作策略+风险等级。

### 周末手动生成瞭望塔晨报

当交易日在周末/节假日需要手动生成报告时：

```python
# Step 1: 采集结构化数据
import sys; sys.path.insert(0, 'scripts')
from data_pipeline import get_index_data, get_north_flow, get_sector_flow_rank, get_top_flow_stocks
from resource_pool import build_resource_pool
import akshare as ak

idx = get_index_data()          # 全球指数
nf = get_north_flow()            # 北向资金
sfr = get_sector_flow_rank()    # 板块资金排名（参数 sector_type='3'）
tfs = get_top_flow_stocks(10)   # 个股资金 TOP N
pool = build_resource_pool()    # 事件池（公告+研报+政策+板块分析）
zt = ak.stock_zt_pool_em(date='YYYYMMDD')          # 涨停板
dt = ak.stock_zt_pool_dtgc_em(date='YYYYMMDD')     # 跌停板

# Step 2: LLM 基于结构化数据编译报告
# → 七段式输出：隔夜外围→前日复盘→资金面→多因子评分→事件矩阵→要闻→研判
```

> ⚠️ `data_pipeline` 导出 `get_sector_flow_rank` (非 `get_sector_rank`)；`resource_pool` 导出 `build_resource_pool()` 函数（非 `ResourcePool` 类）。akshare 涨停板列名是 `封板资金`/`连板数`（非 `封单金额`），跌停用 `stock_zt_pool_dtgc_em`。

详见 → `references/cron-trading-system.md`，完整系统架构 → `~/wiki/交易系统/系统建设需求文档.md`

---

## 输出规范

- 结论先行：代码 → 方向 → 逻辑 → 止损
- 每次分析必标风险等级（高/中/低）
- 用表格呈现关键指标，不用冗长叙述
- 自选池必须注明数据来源和筛选日期
- 口头禅：从基本面看…… 心里有数就好
- **自审查铁律**：每次生成含数据的报告后，必须逐项验证数据来源——对照实时 API 检查关键数值（指数、资金、涨跌停、MA20、公告数、个股事件数），不得凭「看上去合理」放过。详见 `references/system-pitfalls.md`。

---

## 脚本资产

- `scripts/data_pipeline.py` — 统一数据管道（Tushare/AKShare/东方财富/Sina四源聚合）
- `scripts/mega_collector.py` — 🆕 v7.0 统一采集器（9模块14数据源，每小时增量写知识库）
- `scripts/stock_recommender.py` — ⭐ v2.0 选股推荐引擎（V8.0瞭望塔，排除ST/连板/<50亿/>2000亿，板块归类+操作策略，上限9只）
- `scripts/stock_screener.py` — 全市场多因子筛选器
- `scripts/resource_pool.py` — 基本面事件智能池（公告/合同/合作/政策/研报采集+四维交叉验证）
- `scripts/knowledge_base.py` — 基本面知识库（增量采集+去重+倒排索引+检索）
- `scripts/strategy_bridge.py` — 策略引擎桥接器（LLM 可调，4 命令）
- `scripts/auto_executor.py` — 自动交易执行器（信号→风控→执行→日志，paper/live 双模式）
- `scripts/transaction_logger.py` — 结构化交易日志（CSV+SQLite 双写，PnL 统计）
- `scripts/backtest_engine.py` — 回测引擎（夏普/最大回撤/网格搜索/CSV 导出）
- `scripts/paper_trading.py` — Paper Trading 模拟器（滑点/延迟/手续费/移动止盈）
- `scripts/api_server.py` — REST API（FastAPI，17 端点，JWT+限流+Swagger）
- `scripts/notifier.py` — 通知中心（飞书+微信+邮件+短信，P0/P1/P2 分级）
- `scripts/multi_tenant.py` — 多租户管理（4 Tier，API Key SHA-256，PG schema 隔离）
- `strategies/trading_skill_strategies.py` — TradingSkill 风格 5 大策略
- `mcp/` — MCP Gateway（TypeScript，17 tools，5 servers）
- `hardware_box/` — 硬件盒子（Pi 5 install.sh + dashboard.html + led_controller.py）

## 参考文档

- `references/data-source-cheatsheet.md` — 数据源速查表
- `references/screening-pitfalls.md` — 筛选踩坑记录
- `references/trading-system.md` — 小红交易决策系统（三面共振打分+仓位+止盈止损）
- `references/tech-indicators.md` — 技术指标 Python 计算代码模板
- `references/cron-trading-system.md` — Cron 报告系统（各角色+决策官+策略桥接器+no_agent 模式）
- `references/system-pitfalls.md` — 系统审查陷阱清单（14项，按P0/P1/P2分级）
- `references/holdings-operations.md` — holdings.json 清仓/重置/编辑操作手册
- `references/report-formatter-api.md` — 统一报告美化 Report API（双输出：markdown+飞书卡片）
- `references/watchtower-v6-model.md` — 瞭望塔 v6.0 多维交叉验证模型（事件池+四维选股+交叉验证矩阵）
- `references/watchtower-v8-model.md` — ⭐ 瞭望塔 v8.0 架构（单一真相源+自然三段+选股逻辑优先）
- `references/watchtower-v7-model.md` — 瞭望塔 v7.0 架构（mega_collector+stock_recommender+合并晨报）
- `references/watchtower-v6-model.md` — 瞭望塔 v6.0 多维交叉验证模型
- `references/watchtower-v5-model.md` — （已废弃）瞭望塔 v5.0 涨停驱动模型
- `references/knowledge-base-design.md` — 知识库架构：增量采集、哈希去重、倒排索引、检索接口、Cron 配置
- `references/claude-trading-skills-analysis.md` — Claude Trading Skills 生态分析：Skills vs MCP 融合架构
- `references/tradingskill-benchmark.md` — TradingSkill vs 小红系统对标矩阵
- `references/v2-upgrade-plan.md` — v2.0 升级蓝图（5 Phase × 4 Step）
- `references/skills-framework-overview.md` — Skills 框架总览（8 skills + 3 workflows + 4 skillsets）

## Skills 框架

小红采用 **Skills + MCP 双轨架构**（对标 tradermonty/claude-trading-skills）：

```
skills-framework/                    # 声明式技能层
├── skills-index.yaml                # 权威技能注册表
├── skills/                          # 8 个技能
├── workflows/                       # 3 个 YAML 流程
├── skillsets/                       # 4 个场景套装
└── mcp-bridge/                      # Skill ↔ MCP 双向映射
```

**Skills** 提供"做什么、何时做、怎么做"（领域知识+决策框架），**MCP Tools** 提供"拿什么数据、执行什么操作"。四级渐进加载。

## 系统架构文档（Obsidian）

系统整体设计和部署文档在 Obsidian vault (`~/wiki/交易系统/`) 下：
- `~/wiki/交易系统/小红交易系统/运维部署手册.md` — Docker/Pi5/MCP/Cron 完整部署流程
- `~/wiki/交易系统/小红交易系统/用户手册.md` — 小程序/Web/API 用户指南
- `~/wiki/交易系统/系统建设需求文档.md` — 原始需求文档
- `~/wiki/交易系统/Claude-Trading-Skills分析.md` — Skills 生态深度分析
- `references/watchtower-v5-model.md` — （已废弃）瞭望塔 v5.0 涨停驱动模型，被 v6.0 取代
- `references/knowledge-base-design.md` — 知识库架构：增量采集、哈希去重、倒排索引、检索接口、Cron 配置
