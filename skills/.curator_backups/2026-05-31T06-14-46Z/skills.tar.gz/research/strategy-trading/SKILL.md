---
name: strategy-trading
description: 小红策略交易引擎 —— 策略执行、风控分析、交易信号生成
triggers:
  - "策略.*分析"
  - "交易.*信号"
  - "止损.*检查"
  - "风控.*评估"
  - "仓位.*建议"
  - "决策官"
  - "多指标.*策略|组合策略|MA.*交叉|RSI.*策略|布林.*策略"
  - "交易日志|CSV.*日志|PnL.*统计|回测"
  - "Paper Trading|模拟交易|纸交易"
  - "交易.*执行|自动.*下单|执行器"
  - "Docker.*部署|docker-compose|容器化"
  - "硬件.*盒子|树莓派|Raspberry"
category: research
---

# 策略交易引擎

## 桥接器入口

```
python3 ~/.hermes/profiles/xiaohong/scripts/strategy_bridge.py <command> [args]
```

所有输出为 JSON。

## 自动交易执行器 🆕

对标 TradingSkill `src/trading/executor.ts`。

```bash
python3 scripts/auto_executor.py [--paper|--live] [--once|--cron] [--interval SECONDS]
```

### 模式

| 参数 | 说明 |
|------|------|
| `--paper` | 模拟交易（默认），零风险 |
| `--live` | 实盘模式（需券商 API 接入） |
| `--once` | 执行一次信号扫描后退出 |
| `--cron` | Cron 调度模式，同 `--once` |
| `--status` | 输出状态报告后退出 |
| `--interval 300` | 主循环轮询间隔（秒） |

### 架构

```
信号源 (strategy_bridge) → 风控检查 (RiskManager) → 仓位计算 (R值) → 执行 → 日志 (TransactionLogger)
```

### 风控检查清单

执行前必过 4 关：
1. 持仓数 ≤ 9 只
2. 单股仓位 ≤ 33.3%
3. 可用资金足够（留 5% 缓冲）
4. 单笔风险 ≤ 总净值 × 2%（R 值约束）

### 编程调用

```python
from auto_executor import AutoExecutor, Signal, SignalStrength

executor = AutoExecutor(mode="paper")
sig = Signal(symbol="600519", symbol_name="贵州茅台", side="BUY",
             strength=SignalStrength.STRONG, confidence=85.0,
             price=1800.0, stop_loss=1710.0,
             strategy_id="MA-CROSS", reason="金叉突破")

trade_id = executor.process_signal(sig)
# → 买入/卖出执行，返回 trade_id
```

## 交易日志系统 🆕

对标 TradingSkill `src/trading/logger.ts`：CSV + SQLite 双写 + PnL 统计分析。

```bash
python3 scripts/transaction_logger.py [stats|recent|export]
```

### 数据模型

```python
from transaction_logger import TransactionLogger, TradeRecord

logger = TransactionLogger(
    csv_path="workspace/transactions.csv",
    db_path="data/transactions.db"
)

# 便捷方法
logger.log_buy("600519", "茅台", 1800.0, 100, strategy_id="MA-CROSS")
logger.log_sell("600519", "茅台", 1900.0, 100, buy_price=1800.0)

# 统计分析（对标 TradingSkill getStatistics）
stats = logger.get_statistics()
# → {total_trades, wins, losses, win_rate, total_pnl, avg_win, avg_loss, profit_factor, portfolio_value}

# 导出过滤 CSV（对标 TradingSkill exportFiltered）
logger.export_filtered("workspace/btc-only.csv", symbol="600519")
```

### CSV 格式（24 字段）

`Timestamp, TradeID, Symbol, SymbolName, Market, Side, OrderType, Price, Quantity, Value, Fee, StrategyID, SignalType, SignalStrength, SignalConfidence, StopLoss, TakeProfit, PositionPct, IsPaper, ExecStatus, PnL, PnLPct, PortfolioValue, Reason`

### 注意事项

- `log_sell()` 的 PnL 依赖 `buy_price` 参数正确传入，否则为 0
- SQLite 写入失败时 CSV 仍会成功（双写独立）
- `created_at` 由 SQLite `datetime('now')` 自动填充，不需要在代码中传

## 可用命令

| 命令 | 参数 | 说明 |
|------|------|------|
| `list` | 无 | 列出所有可用策略 |
| `signal` | 无 | 生成当前持仓的综合交易信号 |
| `risk` | `[code1 code2 ...]` | 持仓风控分析（止损状态、仓位、盈亏） |
| `run` | `<STRATEGY_ID> [stock_code]` | 运行指定策略 |

## signal 输出示例

```json
{
  "overall_assessment": "🔴 发现 4 个止损警报，建议立即处理",
  "recommendations": [
    {
      "code": "300131",
      "action": "减仓",
      "reason": "仓位 42.9% 超过 33.3% 上限",
      "severity": "warning"
    },
    {
      "code": "600481", 
      "action": "立即卖出",
      "reason": "4 个批次已触发止损",
      "severity": "critical"
    }
  ]
}
```

## 决策官工作流

决策官 (14:30 cron) 的标准化流程：

1. **收集当日数据**：读取 `reports/daily/` 中今日的瞭望塔、侦察兵、狙击手报告
2. **运行风控分析**：`python3 scripts/strategy_bridge.py risk`
3. **运行交易信号**：`python3 scripts/strategy_bridge.py signal`
4. **综合研判**：结合大盘环境 + 持仓状态 + 策略信号，给出决策
5. **输出决策报告**：使用 `report_formatter.Report` 构建美化报告

### 决策报告模板

```python
from report_formatter import Report
import json, subprocess

# 获取风控数据
risk = json.loads(subprocess.run(['python3','scripts/strategy_bridge.py','risk'], capture_output=True, text=True).stdout)
signal = json.loads(subprocess.run(['python3','scripts/strategy_bridge.py','signal'], capture_output=True, text=True).stdout)

r = Report(title="决策官 · 盘中决策", icon="🌹", color="red" if risk['alerts_triggered'] > 0 else "green")
r.header_meta(净值=f"¥{risk['net_value']:,.0f}", 浮亏=f"¥{risk['total_pnl']:+,.0f}", 告警=f"{risk['alerts_triggered']}条")

r.section("行动建议")
for rec in signal['recommendations']:
    icon = {"critical":"🔴","warning":"🟡","info":"🔵","ok":"🟢"}.get(rec['severity'],'⚪')
    r.kv(f"{icon} {rec['code']} {rec['name']}", rec['action'], rec['reason'])

r.section("市场研判")
r.text(填入1句话市场情绪判断)

r.footer("数据 hermes:tushare · 报告时间 14:30")

print(r.markdown())  # cron 自动投递
```

## ## TradingSkill 风格策略集（v2.0 新增）

对标 gwrxuk/TradingSkill → `src/trading/strategies.ts`，新增 5 大策略：

| 策略ID | 信号机制 | 参数 | 文件 |
|--------|----------|------|------|
| MA-CROSS | EMA 快/慢线金叉死叉 | fast=9, slow=21 | `strategies/trading_skill_strategies.py` |
| RSI | 超买超卖反转 | period=14, 30/70 | 同上 |
| MACD | DIF/DEA 金叉死叉 | fast=12, slow=26, sig=9 | 同上 |
| BOLLINGER | 价格触轨反弹 | period=20, std=2.0 | 同上 |
| COMBINED | 加权投票共识 (买≥60分) | MA30%+RSI25%+MACD25%+BB20% | 同上 |

用法：
```python
from strategies.trading_skill_strategies import get_strategy
strat = get_strategy("COMBINED")
signal = strat.analyze("600519", closes_array)
# → StrategySignal(side="BUY", confidence=75.0, stop_loss=1710, ...)
```

## 回测引擎（v2.0 新增）

`scripts/backtest_engine.py` — 历史日线回测 + 参数网格搜索：

```python
from backtest_engine import BacktestEngine
engine = BacktestEngine(initial_capital=100000)
result = engine.run(strategy, "600519", closes, dates)
# → 夏普比率/最大回撤/卡尔玛/胜率/盈亏比/权益曲线

# 网格搜索
results = engine.grid_search(MACrossoverStrategy, "600519", closes,
    {"fast_period": [5,9,13], "slow_period": [20,26,34]})
```

## Paper Trading 增强（v2.0 新增）

`scripts/paper_trading.py` — 滑点/延迟/手续费模拟：

```python
from paper_trading import PaperTradingSimulator
sim = PaperTradingSimulator()
sim.place_order("600519", "BUY", 1800, 100, stop_loss=1710)
sim.update_market_prices({"600519": 1850})
# → 自动跟踪移动止盈
```

### TradingSkill 对标策略

| 策略ID | 名称 | 类型 | 信号机制 | 文件 |
|--------|------|------|---------|------|
| MA-CROSS | 双均线交叉 | 趋势 | EMA快/慢线金叉死叉 | `strategies/trading_skill_strategies.py` |
| RSI | 超买超卖 | 反转 | RSI超卖反弹/超买回落 | 同上 |
| MACD | MACD信号线 | 趋势 | DIF/DEA交叉 | 同上 |
| BOLLINGER | 布林带 | 波动 | 价格触轨反弹 | 同上 |
| COMBINED | 多指标共识 | 综合 | 4策略加权投票(买≥60分) | 同上 |

> 加上小红原生 4 策略（CMP-001/SEL-001/POS-002/STP-001），共 9 策略可用。
> Skills 框架设计详见 `stock-research` → `references/external-skills-ecosystem.md`

## 风控参数

- R 值: ¥6,926.77 (净值 × 33.3% × 1/8 × 凯利 0.2)
- 单股上限: 33.3%
- 总持仓上限: 9 只
- 止损: 技术面 R 系数止损 (3:1 盈亏比)
- 移动止损: 涨 20% 启动，每涨 10% 上移 10%

## 弹药库 --update（持仓同步）

```bash
python3 scripts/ammo_risk.py --update
```

一次调用完成三项操作：
1. **市值同步**：写入 `lastPrice / marketValue / unrealizedPnL / pnlPct`
2. **净值修正**：`currentNetValue = availableCash + sum(marketValue)`
3. **移动止盈**：对浮盈 ≥20% 的批次自动上移止损位

R 值会根据最新净值自动更新。建议每日盘后执行一次。

## signal 输出的 severity 含义

| severity | 含义 | 响应 |
|----------|------|------|
| `critical` | 止损已触发 | 立即清仓 |
| `warning` | 仓位超标或靠近止损 | 减仓或准备 |
| `info` | 浮亏但未触发 | 密切观察 |
| `ok` | 正常 | 持有 |

决策官报告应使用 P0/P1/P2 优先级标注行动项。

## 常见陷阱

- 止损过期：`trailingStopUpdated` 字段可能停滞（弹药库 `--update` 会自动修复）
- 净值偏差：`currentNetValue` 不含浮动盈亏时，R 值和仓位百分比不准确
- 策略引擎验证：`validate_all_strategies()` 应覆盖全部 4 类策略（v1.6 已修复）
- **SQLite INSERT 列数不匹配**：手工数 `?` 容易数错。调试方法：`PRAGMA table_info(transactions)` 查看实际列数，再对照 INSERT 语句计数。本次修复经历：24 列预期但实际 26 列（含 id + created_at），缺 2 个占位符。
- **MACD dea 对齐 bug**：`dea = ema(dif[~np.isnan(dif)], signal)` 返回值长度不等于原始 close 数组，导致 `dea_full[start:start+len(dea)] = dea` 报 `ValueError: could not broadcast`。修复：计算 `first_valid = max(fast, slow) - 1`，`dea_start = first_valid + signal - 1`，`dea_on_valid = dea_raw[~np.isnan(dea_raw)]`，然后 `dea_full[dea_start:end_idx] = dea_on_valid[:end_idx - dea_start]`。
- **Docker TA-Lib 编译**：Raspberry Pi ARM 架构编译慢，建议用预编译 wheel 或 `--build-arg` 跳过；x86 机器正常
- **auto_executor 只在策略桥接返回信号时才执行**，空仓无信号时静默。若需强制测试，用 `process_signal()` 直接注入 Signal 对象
- **Paper Trading numpy import 缺失**：`paper_trading.py` 中 `StrategyPaperTrader.run_cycle` 的类型注解用了 `np.ndarray` 但模块顶部未 `import numpy as np`。务必在 dataclass 模块级 import numpy。

## 瞭望塔集成

决策官应结合瞭望塔 v4.0 的多因子评分和热点板块分析做综合研判：

- 瞭望塔评分 ≥65：积极布局热点板块龙头
- 瞭望塔评分 50-64：精选个股，控制仓位
- 瞭望塔评分 35-49：防御为主，减仓高位品种
- 瞭望塔评分 <35：轻仓观望

热点板块数据可作为决策官选股方向参考。

## 报告美化

统一使用 `report_formatter.Report` 构建所有报告输出。API 详见 `stock-research` skill → `references/report-formatter-api.md`。

```python
from report_formatter import Report
r = Report(title="标题", icon="🌹", color="green")
r.header_meta(日期="2026-05-27", 净值="¥898,698")
r.section("章节名")
r.kv("键", "值", "副文本")
r.table(["表头1","表头2"], [["行1","行2"]])
r.alert("告警信息", "critical")  # critical/warning/info
r.divider()
r.footer("页脚")
print(r.markdown())  # cron stdout 自动投递
```

## Docker 部署 🆕

项目根目录 `~/hermes/profiles/xiaohong/` 下：

```bash
# 一键启动（Paper Trading 模式）
docker-compose up trading-engine -d

# 启动全部服务（含 Grafana 监控）
docker-compose --profile monitoring up -d

# 仅执行一次交易扫描
docker-compose run trading-engine python3 scripts/auto_executor.py --once

# 查看实时日志
docker-compose logs -f trading-engine
```

### 服务矩阵

| 服务 | 容器名 | 端口 | 说明 |
|------|--------|:--:|------|
| trading-engine | xiaohong-engine | — | 核心交易引擎 |
| cron-scheduler | xiaohong-cron | — | 7 角色报告系统 |
| api-server | xiaohong-api | 8000 | FastAPI REST |
| redis | xiaohong-redis | — | 缓存+消息队列 |
| postgres | xiaohong-postgres | — | 多租户数据库 |
| grafana | xiaohong-grafana | 3000 | 监控仪表盘（可选） |